# MV Playlist Builder

로컬 PC에서 실행하는 YouTube 재생목록 변환 앱입니다. 원본 재생목록의 제목을 기준으로 `official music video` 후보를 검색하고, 검토한 선택 항목으로 새 YouTube 재생목록을 만듭니다.

## 준비

1. Google Cloud Console에서 프로젝트를 만들고 **YouTube Data API v3**를 사용 설정합니다.
2. OAuth 동의 화면을 설정합니다.
3. OAuth 클라이언트 ID를 만듭니다.
   - 앱 유형: **웹 애플리케이션**
   - 승인된 리디렉션 URI: `http://localhost:8080/auth/callback`
4. OAuth 클라이언트 JSON을 다운로드해서 이 앱 폴더의 `.local/client_secret.json`으로 저장합니다.

## 실행

```powershell
npm start
```

브라우저에서 `http://localhost:8080`을 열고 YouTube 로그인을 진행하면 됩니다.

## 사용 흐름

1. YouTube 로그인
2. 원본 재생목록 선택 또는 URL/ID 입력
3. 검색할 곡 수와 후보 수 지정
4. 후보 검색
5. 후보를 검토하고 선택
6. 새 재생목록 생성

## 참고

- 토큰은 `.local/token.json`에 저장됩니다. 앱에서 로그아웃하면 이 파일을 삭제합니다.
- 성공한 후보 검색 결과는 `.local/search-cache.json`에 저장됩니다. 같은 곡을 다시 검색할 때는 YouTube `search.list` 호출을 다시 쓰지 않습니다.
- YouTube `search.list`는 곡 1개당 검색 호출 1회를 사용합니다. 공식 문서의 Search Queries quota bucket 기준 기본 한도는 하루 100회로 표시되어 있으니 처음에는 10-25곡 정도로 테스트하는 편이 안전합니다.
- `Quota exceeded for quota metric 'Search Queries'`가 나오면 오늘 자동 검색 한도를 다 쓴 상태입니다. 다음 일일 리셋까지 기다리거나, Google Cloud Console의 **API 및 서비스 → 할당량 → YouTube Data API v3 → Search Queries**에서 한도를 늘려야 합니다.
- 쓰기 권한이 필요해서 OAuth scope는 `https://www.googleapis.com/auth/youtube.force-ssl`을 사용합니다.
- 포트를 바꾸려면 `PORT` 환경 변수를 사용하고 Google Cloud의 Redirect URI도 같은 포트로 맞춰야 합니다.

```powershell
$env:PORT=8090
npm start
```
