"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const fss = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { URL } = require("node:url");

const appRoot = __dirname;
const publicDir = path.join(appRoot, "public");
const localDir = path.join(appRoot, ".local");
const tokenPath = process.env.YOUTUBE_TOKEN_FILE || path.join(localDir, "token.json");
const searchCachePath =
  process.env.YOUTUBE_SEARCH_CACHE_FILE || path.join(localDir, "search-cache.json");
const clientSecretPath =
  process.env.GOOGLE_CLIENT_SECRET_FILE || path.join(localDir, "client_secret.json");
const port = Number(process.env.PORT || 8080);
const redirectUri =
  process.env.GOOGLE_REDIRECT_URI || `http://localhost:${port}/auth/callback`;

const YOUTUBE_SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl"];
const MAX_JSON_BODY_BYTES = 1024 * 1024;

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon"
};

const oauthStates = new Map();
let clientConfigCache = null;
let tokenCache = null;
let searchCacheCache = null;

class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

function base64url(input) {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function sha256(input) {
  return crypto.createHash("sha256").update(input).digest();
}

function clampNumber(value, min, max, fallback) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.max(min, Math.min(max, Math.trunc(numeric)));
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body)
  });
  res.end(body);
}

function sendError(res, error) {
  const status = error.status || 500;
  sendJson(res, status, {
    ok: false,
    message: error.message || "요청을 처리하지 못했습니다.",
    details: error.details
  });
}

function redirect(res, location) {
  res.writeHead(302, { location });
  res.end();
}

function htmlPage(title, message) {
  return `<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${escapeHtml(title)}</title>
    <style>
      body { font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 0; min-height: 100vh; display: grid; place-items: center; background: #f6f7fb; color: #19191f; }
      main { width: min(560px, calc(100vw - 32px)); background: #fff; border: 1px solid #dedfe7; border-radius: 8px; padding: 28px; box-shadow: 0 18px 45px rgba(20, 20, 25, .08); }
      a { color: #d9002f; }
    </style>
  </head>
  <body>
    <main>
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(message)}</p>
      <p><a href="/">앱으로 돌아가기</a></p>
    </main>
  </body>
</html>`;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];

    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_JSON_BODY_BYTES) {
        reject(new ApiError(413, "요청 본문이 너무 큽니다."));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on("end", () => {
      if (chunks.length === 0) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch {
        reject(new ApiError(400, "JSON 형식이 올바르지 않습니다."));
      }
    });

    req.on("error", reject);
  });
}

async function loadClientConfig() {
  if (clientConfigCache) return clientConfigCache;

  if (process.env.GOOGLE_CLIENT_ID) {
    clientConfigCache = {
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
      authUri: process.env.GOOGLE_AUTH_URI || "https://accounts.google.com/o/oauth2/v2/auth",
      tokenUri: process.env.GOOGLE_TOKEN_URI || "https://oauth2.googleapis.com/token"
    };
    return clientConfigCache;
  }

  let raw;
  try {
    raw = await fs.readFile(clientSecretPath, "utf8");
  } catch {
    throw new ApiError(400, "Google OAuth 설정 파일을 찾지 못했습니다.", {
      expectedFile: clientSecretPath
    });
  }

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new ApiError(400, "Google OAuth 설정 파일의 JSON 형식이 올바르지 않습니다.", {
      expectedFile: clientSecretPath
    });
  }

  const source = parsed.web || parsed.installed || parsed;
  if (!source.client_id) {
    throw new ApiError(400, "Google OAuth 설정에 client_id가 없습니다.", {
      expectedFile: clientSecretPath
    });
  }

  clientConfigCache = {
    clientId: source.client_id,
    clientSecret: source.client_secret || "",
    authUri: source.auth_uri || "https://accounts.google.com/o/oauth2/v2/auth",
    tokenUri: source.token_uri || "https://oauth2.googleapis.com/token"
  };
  return clientConfigCache;
}

async function readStoredTokens() {
  if (tokenCache) return tokenCache;

  try {
    const raw = await fs.readFile(tokenPath, "utf8");
    tokenCache = JSON.parse(raw);
    return tokenCache;
  } catch {
    return null;
  }
}

async function saveTokens(tokens) {
  await fs.mkdir(localDir, { recursive: true });
  tokenCache = tokens;
  await fs.writeFile(tokenPath, JSON.stringify(tokens, null, 2), "utf8");
}

async function clearTokens() {
  tokenCache = null;
  await fs.rm(tokenPath, { force: true });
}

async function readSearchCache() {
  if (searchCacheCache) return searchCacheCache;

  try {
    const raw = await fs.readFile(searchCachePath, "utf8");
    const parsed = JSON.parse(raw);
    searchCacheCache = {
      version: 1,
      entries: parsed.entries && typeof parsed.entries === "object" ? parsed.entries : {}
    };
  } catch {
    searchCacheCache = { version: 1, entries: {} };
  }

  return searchCacheCache;
}

async function saveSearchCache(cache) {
  const entries = Object.entries(cache.entries || {});
  if (entries.length > 1000) {
    entries
      .sort((a, b) => String(b[1].createdAt || "").localeCompare(String(a[1].createdAt || "")))
      .slice(1000)
      .forEach(([key]) => {
        delete cache.entries[key];
      });
  }

  searchCacheCache = cache;
  await fs.mkdir(localDir, { recursive: true });
  await fs.writeFile(searchCachePath, JSON.stringify(cache, null, 2), "utf8");
}

function searchCacheKey(source, identity, searchLimit) {
  return base64url(
    sha256(
      JSON.stringify({
        v: 1,
        videoId: source.videoId,
        title: source.title,
        channelTitle: source.channelTitle,
        query: identity.query,
        searchLimit
      })
    )
  );
}

async function getSearchCacheEntry(key) {
  const cache = await readSearchCache();
  const entry = cache.entries[key];
  return entry?.result || null;
}

async function setSearchCacheEntry(key, result) {
  const cache = await readSearchCache();
  cache.entries[key] = {
    createdAt: new Date().toISOString(),
    result
  };
  await saveSearchCache(cache);
}

async function requestGoogleToken(params) {
  const client = await loadClientConfig();
  const body = new URLSearchParams(params);
  body.set("client_id", client.clientId);
  if (client.clientSecret) body.set("client_secret", client.clientSecret);

  const response = await fetch(client.tokenUri, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new ApiError(
      response.status,
      payload.error_description || payload.error || "Google OAuth 토큰 요청에 실패했습니다.",
      payload
    );
  }

  return payload;
}

async function getValidAccessToken() {
  const tokens = await readStoredTokens();
  if (!tokens) throw new ApiError(401, "YouTube 로그인이 필요합니다.");

  if (tokens.access_token && tokens.expiry_date && Date.now() < tokens.expiry_date - 60_000) {
    return tokens.access_token;
  }

  if (!tokens.refresh_token) {
    throw new ApiError(401, "로그인 토큰이 만료되었습니다. 다시 로그인해 주세요.");
  }

  const refreshed = await requestGoogleToken({
    grant_type: "refresh_token",
    refresh_token: tokens.refresh_token
  });

  const merged = {
    ...tokens,
    ...refreshed,
    refresh_token: refreshed.refresh_token || tokens.refresh_token,
    expiry_date: Date.now() + Number(refreshed.expires_in || 3600) * 1000
  };
  await saveTokens(merged);
  return merged.access_token;
}

function youtubeApiError(resource, status, payload) {
  const apiMessage =
    payload?.error?.message ||
    payload?.error_description ||
    payload?.error ||
    "YouTube API 요청에 실패했습니다.";
  const combined = `${resource} ${apiMessage} ${JSON.stringify(payload || {})}`;

  if (/quota exceeded|quotaExceeded|Search Queries/i.test(combined)) {
    const isSearchQuota = /Search Queries/i.test(combined) || resource === "search";
    return new ApiError(
      429,
      isSearchQuota
        ? "YouTube 검색 일일 한도를 다 썼습니다. 오늘은 뮤비 후보 자동 검색을 더 할 수 없어요. 내일 다시 시도하거나, Google Cloud Console에서 Search Queries 할당량을 늘려야 합니다."
        : "YouTube API 할당량을 다 썼습니다. Google Cloud Console의 YouTube Data API 할당량을 확인해 주세요.",
      payload
    );
  }

  return new ApiError(status, apiMessage, payload);
}

async function youtubeApi(resource, params = {}, options = {}, retry = true) {
  const accessToken = await getValidAccessToken();
  const url = new URL(`https://www.googleapis.com/youtube/v3/${resource}`);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  }

  const headers = { authorization: `Bearer ${accessToken}` };
  let body;
  if (options.body !== undefined) {
    headers["content-type"] = "application/json; charset=utf-8";
    body = JSON.stringify(options.body);
  }

  const response = await fetch(url, {
    method: options.method || "GET",
    headers,
    body
  });

  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};

  if (response.status === 401 && retry) {
    const tokens = await readStoredTokens();
    if (tokens?.refresh_token) {
      await saveTokens({ ...tokens, expiry_date: 0 });
      return youtubeApi(resource, params, options, false);
    }
  }

  if (!response.ok) {
    throw youtubeApiError(resource, response.status, payload);
  }

  return payload;
}

function parsePlaylistId(input) {
  const value = String(input || "").trim();
  if (!value) throw new ApiError(400, "재생목록 ID가 비어 있습니다.");

  try {
    const parsed = new URL(value);
    const list = parsed.searchParams.get("list");
    if (list) return list.trim();
  } catch {
    // Treat the input as a raw playlist ID.
  }

  const match = value.match(/[?&]list=([^&]+)/);
  return decodeURIComponent(match?.[1] || value).trim();
}

async function fetchAllPages(resource, params, maxItems = Infinity) {
  const items = [];
  let pageToken;

  do {
    const remaining = maxItems === Infinity ? 50 : Math.max(1, maxItems - items.length);
    const payload = await youtubeApi(resource, {
      ...params,
      maxResults: Math.min(50, remaining),
      pageToken
    });
    items.push(...(payload.items || []));
    pageToken = payload.nextPageToken;
  } while (pageToken && items.length < maxItems);

  return items.slice(0, maxItems);
}

function bestThumbnail(thumbnails = {}) {
  return (
    thumbnails.maxres?.url ||
    thumbnails.standard?.url ||
    thumbnails.high?.url ||
    thumbnails.medium?.url ||
    thumbnails.default?.url ||
    ""
  );
}

function simplifyPlaylist(item) {
  return {
    id: item.id,
    title: item.snippet?.title || "(제목 없음)",
    channelTitle: item.snippet?.channelTitle || "",
    thumbnail: bestThumbnail(item.snippet?.thumbnails),
    itemCount: item.contentDetails?.itemCount || 0,
    privacyStatus: item.status?.privacyStatus || ""
  };
}

function simplifyPlaylistItem(item) {
  const snippet = item.snippet || {};
  const videoId = item.contentDetails?.videoId || snippet.resourceId?.videoId;

  return {
    playlistItemId: item.id,
    videoId,
    title: snippet.title || "(제목 없음)",
    channelTitle: snippet.videoOwnerChannelTitle || snippet.channelTitle || "",
    thumbnail: bestThumbnail(snippet.thumbnails),
    publishedAt: snippet.publishedAt || ""
  };
}

function normalizeText(value) {
  return String(value || "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9가-힣ぁ-んァ-ン一-龯]+/g, " ")
    .trim();
}

function removeBracketedDescriptors(title) {
  let output = title;
  const descriptorPattern =
    /(official\s+)?(music\s+video|mv|m\/v|audio|lyrics?|lyric\s+video|visualizer|cover|album\s+art|topic|provided\s+to\s+youtube|remaster(?:ed)?|full\s+album)/i;
  output = output.replace(/\s*[\[(][^\])]*(official\s+)?(music\s+video|mv|m\/v|audio|lyrics?|lyric\s+video|visualizer|cover|album\s+art|provided\s+to\s+youtube)[^\])]*[\])]/gi, " ");
  output = output.replace(/\s+-\s*(official\s+)?(audio|lyrics?|visualizer|cover|topic)\s*$/i, " ");
  output = output.replace(descriptorPattern, (match) => {
    return /^(official\s+)?(music\s+video|mv|m\/v)$/i.test(match.trim()) ? " " : match;
  });
  return output.replace(/\s+/g, " ").trim();
}

function cleanChannelArtist(channelTitle) {
  const cleaned = String(channelTitle || "")
    .replace(/\s+-\s+Topic$/i, "")
    .replace(/\s+VEVO$/i, "")
    .replace(/\s+Official$/i, "")
    .replace(/\s+Records$/i, "")
    .trim();

  if (!cleaned || /youtube|various artists|topic/i.test(cleaned)) return "";
  return cleaned;
}

function extractSourceIdentity(source) {
  const rawTitle = String(source.title || "");
  const withoutDescriptors = removeBracketedDescriptors(rawTitle);
  const parts = withoutDescriptors.split(/\s+[-–—]\s+/).filter(Boolean);
  let artist = "";
  let songTitle = withoutDescriptors;

  if (parts.length >= 2 && parts[0].length <= 70) {
    artist = parts.shift().trim();
    songTitle = parts.join(" - ").trim();
  }

  const ownerArtist = cleanChannelArtist(source.channelTitle);
  const artistGuess = artist || ownerArtist;

  return {
    artist: artistGuess,
    cleanTitle: songTitle || rawTitle,
    query: [artistGuess, songTitle || rawTitle, "official music video"].filter(Boolean).join(" ")
  };
}

function parseDurationSeconds(isoDuration) {
  const match = String(isoDuration || "").match(
    /^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/
  );
  if (!match) return 0;
  const [, days, hours, minutes, seconds] = match.map((value) => Number(value || 0));
  return days * 86400 + hours * 3600 + minutes * 60 + seconds;
}

function formatDuration(seconds) {
  if (!seconds) return "";
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  if (minutes < 60) return `${minutes}:${String(remainder).padStart(2, "0")}`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}:${String(mins).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function tokenSet(value) {
  return new Set(
    normalizeText(value)
      .split(/\s+/)
      .filter((token) => token.length > 1)
  );
}

function overlapScore(needle, haystack) {
  const needleTokens = tokenSet(needle);
  if (needleTokens.size === 0) return 0;
  const haystackTokens = tokenSet(haystack);
  let hits = 0;
  for (const token of needleTokens) {
    if (haystackTokens.has(token)) hits += 1;
  }
  return hits / needleTokens.size;
}

function includesPhrase(text, phrase) {
  return normalizeText(text).includes(normalizeText(phrase));
}

function scoreCandidate(source, identity, video) {
  const title = video.snippet?.title || "";
  const channel = video.snippet?.channelTitle || "";
  const durationSeconds = parseDurationSeconds(video.contentDetails?.duration);
  const titleAndChannel = `${title} ${channel}`;
  const normalizedTitle = normalizeText(title);
  const reasons = [];
  let score = 0;

  if (video.id === source.videoId) {
    score -= 200;
    reasons.push("원본 영상 제외");
  }

  const titleOverlap = overlapScore(identity.cleanTitle, title);
  score += titleOverlap * 45;
  if (titleOverlap >= 0.75) reasons.push("제목 일치");

  if (identity.artist) {
    const artistOverlap = overlapScore(identity.artist, titleAndChannel);
    score += artistOverlap * 24;
    if (artistOverlap >= 0.6) reasons.push("아티스트 일치");
  }

  if (includesPhrase(title, identity.cleanTitle)) score += 18;

  const positivePatterns = [
    { pattern: /\bofficial music video\b/i, label: "Official Music Video" },
    { pattern: /\bofficial video\b/i, label: "Official Video" },
    { pattern: /\bmusic video\b/i, label: "Music Video" },
    { pattern: /\bm\/v\b/i, label: "M/V" },
    { pattern: /\bmv\b/i, label: "MV" },
    { pattern: /뮤직비디오|뮤비/i, label: "뮤직비디오" }
  ];

  for (const { pattern, label } of positivePatterns) {
    if (pattern.test(title)) {
      score += 20;
      reasons.push(label);
      break;
    }
  }

  if (/\b(vevo|official)\b/i.test(channel)) {
    score += 14;
    reasons.push("공식 채널 신호");
  }

  const negativePatterns = [
    { pattern: /\blyrics?\b|\blyric video\b/i, label: "가사 영상" },
    { pattern: /\bofficial audio\b|\baudio\b/i, label: "오디오 영상" },
    { pattern: /\bvisualizer\b/i, label: "비주얼라이저" },
    { pattern: /\bcover\b/i, label: "커버 영상" },
    { pattern: /\bkaraoke\b|\binstrumental\b/i, label: "반주/인스트루멘털" },
    { pattern: /\breaction\b|\bsped up\b|\bslowed\b|\bnightcore\b/i, label: "파생 영상" }
  ];

  for (const { pattern, label } of negativePatterns) {
    if (pattern.test(title)) {
      score -= 34;
      reasons.push(label);
    }
  }

  if (/\blive\b/i.test(normalizedTitle) && !/\bofficial music video\b/i.test(title)) {
    score -= 16;
    reasons.push("라이브 가능성");
  }

  if (durationSeconds >= 90 && durationSeconds <= 720) score += 10;
  if (durationSeconds > 0 && durationSeconds < 60) score -= 25;
  if (durationSeconds > 1200) score -= 18;

  const viewCount = Number(video.statistics?.viewCount || 0);
  if (viewCount > 0) score += Math.min(15, Math.log10(viewCount));

  return {
    score: Math.round(score),
    reasons: [...new Set(reasons)].slice(0, 4),
    durationSeconds,
    duration: formatDuration(durationSeconds),
    viewCount
  };
}

async function listPlaylistItems(playlistId, maxItems) {
  const items = await fetchAllPages(
    "playlistItems",
    {
      part: "snippet,contentDetails,status",
      playlistId
    },
    maxItems
  );

  return items
    .map(simplifyPlaylistItem)
    .filter((item) => item.videoId && !/^deleted video$|^private video$/i.test(item.title));
}

async function searchMusicVideoCandidates(source, searchLimit) {
  const identity = extractSourceIdentity(source);
  const cacheKey = searchCacheKey(source, identity, searchLimit);
  const cached = await getSearchCacheEntry(cacheKey);
  if (cached) return { ...cached, fromCache: true };

  const searchPayload = await youtubeApi("search", {
    part: "snippet",
    type: "video",
    order: "relevance",
    safeSearch: "none",
    q: identity.query,
    maxResults: searchLimit
  });

  const videoIds = (searchPayload.items || [])
    .map((item) => item.id?.videoId)
    .filter(Boolean);

  if (videoIds.length === 0) {
    const emptyResult = { identity, candidates: [] };
    await setSearchCacheEntry(cacheKey, emptyResult);
    return { ...emptyResult, fromCache: false };
  }

  const details = await youtubeApi("videos", {
    part: "snippet,contentDetails,statistics,status",
    id: videoIds.join(",")
  });

  const candidates = (details.items || [])
    .map((video) => {
      const score = scoreCandidate(source, identity, video);
      return {
        videoId: video.id,
        title: video.snippet?.title || "(제목 없음)",
        channelTitle: video.snippet?.channelTitle || "",
        thumbnail: bestThumbnail(video.snippet?.thumbnails),
        url: `https://www.youtube.com/watch?v=${video.id}`,
        duration: score.duration,
        durationSeconds: score.durationSeconds,
        score: score.score,
        reasons: score.reasons,
        viewCount: score.viewCount,
        privacyStatus: video.status?.privacyStatus || ""
      };
    })
    .sort((a, b) => b.score - a.score);

  const result = { identity, candidates };
  await setSearchCacheEntry(cacheKey, result);
  return { ...result, fromCache: false };
}

async function handleAuthStart(res) {
  const client = await loadClientConfig();
  const state = base64url(crypto.randomBytes(32));
  const verifier = base64url(crypto.randomBytes(64));
  const challenge = base64url(sha256(verifier));
  oauthStates.set(state, { verifier, createdAt: Date.now() });

  for (const [key, value] of oauthStates) {
    if (Date.now() - value.createdAt > 10 * 60 * 1000) oauthStates.delete(key);
  }

  const authUrl = new URL(client.authUri);
  authUrl.searchParams.set("client_id", client.clientId);
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("scope", YOUTUBE_SCOPES.join(" "));
  authUrl.searchParams.set("access_type", "offline");
  authUrl.searchParams.set("include_granted_scopes", "true");
  authUrl.searchParams.set("prompt", "consent");
  authUrl.searchParams.set("state", state);
  authUrl.searchParams.set("code_challenge", challenge);
  authUrl.searchParams.set("code_challenge_method", "S256");

  redirect(res, authUrl.toString());
}

async function handleAuthCallback(req, res) {
  const url = new URL(req.url, `http://localhost:${port}`);
  const error = url.searchParams.get("error");
  if (error) {
    res.writeHead(400, { "content-type": "text/html; charset=utf-8" });
    res.end(htmlPage("로그인 실패", error));
    return;
  }

  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const stateRecord = state ? oauthStates.get(state) : null;
  if (!code || !stateRecord) {
    res.writeHead(400, { "content-type": "text/html; charset=utf-8" });
    res.end(htmlPage("로그인 실패", "OAuth state가 일치하지 않습니다."));
    return;
  }
  oauthStates.delete(state);

  const existing = await readStoredTokens();
  const tokenPayload = await requestGoogleToken({
    code,
    grant_type: "authorization_code",
    redirect_uri: redirectUri,
    code_verifier: stateRecord.verifier
  });

  const tokens = {
    ...existing,
    ...tokenPayload,
    refresh_token: tokenPayload.refresh_token || existing?.refresh_token,
    expiry_date: Date.now() + Number(tokenPayload.expires_in || 3600) * 1000
  };
  await saveTokens(tokens);
  redirect(res, "/?login=ok");
}

async function handleApi(req, res, url) {
  if (url.pathname === "/api/config" && req.method === "GET") {
    let configured = true;
    let configError = null;
    try {
      await loadClientConfig();
    } catch (error) {
      configured = false;
      configError = error.message;
    }

    const storedTokens = await readStoredTokens();
    sendJson(res, 200, {
      ok: true,
      configured,
      configError,
      redirectUri,
      expectedClientSecretFile: clientSecretPath,
      scopes: YOUTUBE_SCOPES,
      hasStoredToken: Boolean(storedTokens)
    });
    return;
  }

  if (url.pathname === "/api/me" && req.method === "GET") {
    const payload = await youtubeApi("channels", {
      part: "snippet,contentDetails,statistics",
      mine: "true"
    });
    const channel = payload.items?.[0];
    sendJson(res, 200, {
      ok: true,
      channel: channel
        ? {
            id: channel.id,
            title: channel.snippet?.title || "",
            thumbnail: bestThumbnail(channel.snippet?.thumbnails),
            subscriberCount: channel.statistics?.subscriberCount || ""
          }
        : null
    });
    return;
  }

  if (url.pathname === "/api/logout" && req.method === "POST") {
    await clearTokens();
    sendJson(res, 200, { ok: true });
    return;
  }

  if (url.pathname === "/api/playlists" && req.method === "GET") {
    const items = await fetchAllPages(
      "playlists",
      {
        part: "snippet,contentDetails,status",
        mine: "true"
      },
      250
    );
    sendJson(res, 200, {
      ok: true,
      playlists: items.map(simplifyPlaylist)
    });
    return;
  }

  if (url.pathname === "/api/playlist-items" && req.method === "GET") {
    const playlistId = parsePlaylistId(url.searchParams.get("playlistId"));
    const maxItems = clampNumber(url.searchParams.get("maxItems"), 1, 500, 100);
    const items = await listPlaylistItems(playlistId, maxItems);
    sendJson(res, 200, { ok: true, playlistId, items });
    return;
  }

  if (url.pathname === "/api/match" && req.method === "POST") {
    const body = await readJsonBody(req);
    const playlistId = parsePlaylistId(body.playlistId);
    const maxItems = clampNumber(body.maxItems, 1, 200, 10);
    const searchLimit = clampNumber(body.searchLimit, 1, 10, 5);
    const sourceItems = await listPlaylistItems(playlistId, maxItems);
    const matches = [];
    let searchCalls = 0;

    for (const source of sourceItems) {
      try {
        const { identity, candidates, fromCache } = await searchMusicVideoCandidates(
          source,
          searchLimit
        );
        if (!fromCache) searchCalls += 1;
        const best = candidates[0];
        matches.push({
          source,
          cleanedTitle: identity.cleanTitle,
          artist: identity.artist,
          query: identity.query,
          candidates,
          selectedVideoId: best && best.score >= 35 ? best.videoId : "",
          needsReview: !best || best.score < 55,
          fromCache
        });
      } catch (error) {
        if ([401, 403, 429].includes(error.status)) throw error;
        matches.push({
          source,
          cleanedTitle: source.title,
          artist: "",
          query: "",
          candidates: [],
          selectedVideoId: "",
          needsReview: true,
          error: error.message
        });
      }
    }

    sendJson(res, 200, {
      ok: true,
      playlistId,
      itemCount: sourceItems.length,
      searchLimit,
      searchCostEstimate: searchCalls,
      cachedCount: sourceItems.length - searchCalls,
      matches
    });
    return;
  }

  if (url.pathname === "/api/create-playlist" && req.method === "POST") {
    const body = await readJsonBody(req);
    const title = String(body.title || "").trim() || "Music Video Playlist";
    const privacyStatus = ["private", "unlisted", "public"].includes(body.privacyStatus)
      ? body.privacyStatus
      : "private";
    const selectedMatches = Array.isArray(body.matches) ? body.matches : [];
    const dedupe = body.dedupe !== false;
    const selectedVideoIds = selectedMatches
      .map((match) => String(match.selectedVideoId || "").trim())
      .filter(Boolean);
    const videoIds = dedupe ? [...new Set(selectedVideoIds)] : selectedVideoIds;

    if (videoIds.length === 0) {
      throw new ApiError(400, "새 재생목록에 넣을 영상이 없습니다.");
    }

    const description =
      String(body.description || "").trim() ||
      `Created from ${selectedMatches.length} playlist matches by the local MV Playlist Builder.`;

    const created = await youtubeApi(
      "playlists",
      { part: "snippet,status" },
      {
        method: "POST",
        body: {
          snippet: {
            title,
            description
          },
          status: {
            privacyStatus
          }
        }
      }
    );

    const playlistId = created.id;
    const added = [];
    const failed = [];

    for (const videoId of videoIds) {
      try {
        const item = await youtubeApi(
          "playlistItems",
          { part: "snippet" },
          {
            method: "POST",
            body: {
              snippet: {
                playlistId,
                resourceId: {
                  kind: "youtube#video",
                  videoId
                }
              }
            }
          }
        );
        added.push({ videoId, playlistItemId: item.id });
      } catch (error) {
        failed.push({ videoId, message: error.message });
      }
    }

    sendJson(res, 200, {
      ok: true,
      playlistId,
      url: `https://www.youtube.com/playlist?list=${playlistId}`,
      title,
      requested: videoIds.length,
      added,
      failed
    });
    return;
  }

  throw new ApiError(404, "API 경로를 찾지 못했습니다.");
}

async function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") pathname = "/index.html";
  const target = path.resolve(publicDir, `.${pathname}`);

  if (target !== publicDir && !target.startsWith(`${publicDir}${path.sep}`)) {
    throw new ApiError(403, "허용되지 않은 파일 경로입니다.");
  }

  if (!fss.existsSync(target) || !fss.statSync(target).isFile()) {
    throw new ApiError(404, "파일을 찾지 못했습니다.");
  }

  const ext = path.extname(target).toLowerCase();
  res.writeHead(200, { "content-type": MIME_TYPES[ext] || "application/octet-stream" });
  fss.createReadStream(target).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://localhost:${port}`);

    if (url.pathname === "/auth/start") {
      await handleAuthStart(res);
      return;
    }

    if (url.pathname === "/auth/callback") {
      await handleAuthCallback(req, res);
      return;
    }

    if (url.pathname.startsWith("/api/")) {
      await handleApi(req, res, url);
      return;
    }

    await serveStatic(req, res, url);
  } catch (error) {
    if (res.headersSent) {
      res.end();
      return;
    }
    if (req.url?.startsWith("/api/")) {
      sendError(res, error);
      return;
    }
    res.writeHead(error.status || 500, { "content-type": "text/html; charset=utf-8" });
    res.end(htmlPage("오류", error.message || "요청을 처리하지 못했습니다."));
  }
});

server.listen(port, () => {
  console.log(`MV Playlist Builder running at http://localhost:${port}`);
  console.log(`OAuth redirect URI: ${redirectUri}`);
  console.log(`Client secret file: ${clientSecretPath}`);
});
