const state = {
  config: null,
  me: null,
  playlists: [],
  matches: [],
  selected: {},
  matchMeta: null,
  busy: false
};

const $ = (selector) => document.querySelector(selector);

const els = {
  appSubtitle: $("#appSubtitle"),
  accountLabel: $("#accountLabel"),
  statusDot: $("#statusDot"),
  loginBtn: $("#loginBtn"),
  logoutBtn: $("#logoutBtn"),
  setupPanel: $("#setupPanel"),
  redirectUriText: $("#redirectUriText"),
  clientFileText: $("#clientFileText"),
  refreshPlaylistsBtn: $("#refreshPlaylistsBtn"),
  playlistSelect: $("#playlistSelect"),
  playlistInput: $("#playlistInput"),
  maxItemsInput: $("#maxItemsInput"),
  searchLimitInput: $("#searchLimitInput"),
  matchBtn: $("#matchBtn"),
  newTitleInput: $("#newTitleInput"),
  privacySelect: $("#privacySelect"),
  dedupeInput: $("#dedupeInput"),
  createBtn: $("#createBtn"),
  notice: $("#notice"),
  totalCount: $("#totalCount"),
  selectedCount: $("#selectedCount"),
  reviewCount: $("#reviewCount"),
  quotaCount: $("#quotaCount"),
  selectBestBtn: $("#selectBestBtn"),
  clearSelectionBtn: $("#clearSelectionBtn"),
  resultPanel: $("#resultPanel"),
  matchList: $("#matchList")
};

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatNumber(value) {
  const numeric = Number(value || 0);
  return new Intl.NumberFormat("ko-KR").format(numeric);
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  let body = options.body;
  if (body && typeof body !== "string") {
    headers["content-type"] = "application/json; charset=utf-8";
    body = JSON.stringify(body);
  }

  const response = await fetch(path, { ...options, headers, body });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.message || response.statusText);
    error.status = response.status;
    error.details = payload.details;
    throw error;
  }
  return payload;
}

function setNotice(kind, message) {
  if (!message) {
    els.notice.className = "notice hidden";
    els.notice.textContent = "";
    return;
  }
  els.notice.className = `notice ${kind || ""}`.trim();
  els.notice.textContent = message;
}

function setBusy(busy, label = "처리 중") {
  state.busy = busy;
  const disabled = busy || !state.me || !state.config?.configured;
  els.matchBtn.disabled = disabled;
  els.createBtn.disabled = disabled || selectedCount() === 0;
  els.refreshPlaylistsBtn.disabled = busy || !state.me;
  els.selectBestBtn.disabled = busy || state.matches.length === 0;
  els.clearSelectionBtn.disabled = busy || state.matches.length === 0;
  els.matchBtn.textContent = busy ? label : "뮤비 후보 찾기";
}

function selectedCount() {
  return Object.values(state.selected).filter(Boolean).length;
}

function reviewCount() {
  return state.matches.filter((match, index) => match.needsReview || !state.selected[index]).length;
}

function parsePlaylistId(input) {
  const value = String(input || "").trim();
  if (!value) return "";
  try {
    const parsed = new URL(value);
    return parsed.searchParams.get("list") || value;
  } catch {
    const match = value.match(/[?&]list=([^&]+)/);
    return match?.[1] ? decodeURIComponent(match[1]) : value;
  }
}

function renderAuth() {
  const configured = Boolean(state.config?.configured);
  els.setupPanel.classList.toggle("hidden", configured);
  els.redirectUriText.textContent = state.config?.redirectUri || "";
  els.clientFileText.textContent = state.config?.expectedClientSecretFile || "";

  els.loginBtn.disabled = !configured || state.busy;
  els.loginBtn.classList.toggle("hidden", Boolean(state.me));
  els.logoutBtn.classList.toggle("hidden", !state.me);

  if (!configured) {
    els.statusDot.className = "status-dot offline";
    els.accountLabel.textContent = "OAuth 설정 필요";
    els.appSubtitle.textContent = "Google Cloud 설정을 먼저 연결";
  } else if (state.me) {
    els.statusDot.className = "status-dot connected";
    els.accountLabel.textContent = state.me.title || "YouTube 연결됨";
    els.appSubtitle.textContent = "뮤비 후보 검토 및 재생목록 생성";
  } else {
    els.statusDot.className = "status-dot";
    els.accountLabel.textContent = "로그인 필요";
    els.appSubtitle.textContent = "YouTube 로그인을 기다리는 중";
  }

  const controlsDisabled = !state.me || !configured || state.busy;
  [
    els.playlistSelect,
    els.playlistInput,
    els.maxItemsInput,
    els.searchLimitInput,
    els.newTitleInput,
    els.privacySelect,
    els.dedupeInput
  ].forEach((control) => {
    control.disabled = controlsDisabled;
  });

  setBusy(state.busy);
}

function renderPlaylists() {
  const options = ['<option value="">직접 입력</option>']
    .concat(
      state.playlists.map((playlist) => {
        const label = `${playlist.title} (${formatNumber(playlist.itemCount)})`;
        return `<option value="${escapeHtml(playlist.id)}">${escapeHtml(label)}</option>`;
      })
    )
    .join("");

  els.playlistSelect.innerHTML = options;
}

function renderMetrics() {
  els.totalCount.textContent = formatNumber(state.matches.length);
  els.selectedCount.textContent = formatNumber(selectedCount());
  els.reviewCount.textContent = formatNumber(reviewCount());
  els.quotaCount.textContent = formatNumber(state.matchMeta?.searchCostEstimate || 0);
  els.createBtn.disabled = state.busy || !state.me || selectedCount() === 0;
}

function renderResult(result) {
  if (!result) {
    els.resultPanel.classList.add("hidden");
    els.resultPanel.innerHTML = "";
    return;
  }

  els.resultPanel.classList.remove("hidden");
  const failed = result.failed?.length || 0;
  els.resultPanel.innerHTML = `
    <strong>${escapeHtml(result.title)} 생성 완료</strong>
    <div>${formatNumber(result.added?.length || 0)}개 추가${
      failed ? `, ${formatNumber(failed)}개 실패` : ""
    }</div>
    <div><a href="${escapeHtml(result.url)}" target="_blank" rel="noreferrer">YouTube에서 열기</a></div>
  `;
}

function candidateScoreClass(candidate) {
  return candidate?.score >= 55 ? "" : "review";
}

function renderCandidate(match, index, candidate) {
  const selected = state.selected[index] === candidate.videoId;
  const reasons = candidate.reasons?.length
    ? `<div class="reason-list">${candidate.reasons
        .map((reason) => `<span>${escapeHtml(reason)}</span>`)
        .join("")}</div>`
    : "";

  return `
    <div class="candidate-row ${selected ? "selected" : ""}">
      <img class="thumb" src="${escapeHtml(candidate.thumbnail)}" alt="">
      <div>
        <div class="candidate-title">
          <a href="${escapeHtml(candidate.url)}" target="_blank" rel="noreferrer">${escapeHtml(
            candidate.title
          )}</a>
        </div>
        <div class="meta-line">${escapeHtml(candidate.channelTitle)}${
          candidate.duration ? ` · ${escapeHtml(candidate.duration)}` : ""
        } · 점수 ${formatNumber(candidate.score)}</div>
        ${reasons}
      </div>
      <button class="candidate-action" type="button" data-index="${index}" data-video="${escapeHtml(
        candidate.videoId
      )}">${selected ? "선택됨" : "선택"}</button>
    </div>
  `;
}

function renderMatch(match, index) {
  const selectedVideoId = state.selected[index];
  const selectedCandidate = match.candidates.find((candidate) => candidate.videoId === selectedVideoId);
  const scoreLabel = selectedCandidate ? `점수 ${formatNumber(selectedCandidate.score)}` : "검토";
  const candidateRows = match.candidates.length
    ? match.candidates.map((candidate) => renderCandidate(match, index, candidate)).join("")
    : `<div class="candidate-row skip-row"><div class="meta-line">${
        match.error ? escapeHtml(match.error) : "후보 없음"
      }</div><button class="candidate-action" type="button" disabled>선택</button></div>`;
  const skipSelected = !state.selected[index];

  return `
    <article class="match-card">
      <div class="match-header">
        <img class="thumb" src="${escapeHtml(match.source.thumbnail)}" alt="">
        <div>
          <div class="source-title">${escapeHtml(match.source.title)}</div>
          <div class="meta-line">${escapeHtml(match.source.channelTitle || "")}</div>
          <div class="meta-line">검색: ${escapeHtml(match.query || match.cleanedTitle || "")}</div>
        </div>
        <div class="score-pill ${candidateScoreClass(selectedCandidate)}">${escapeHtml(scoreLabel)}</div>
      </div>
      <div class="candidate-list">
        ${candidateRows}
        <div class="candidate-row skip-row ${skipSelected ? "selected" : ""}">
          <div>
            <div class="candidate-title">건너뛰기</div>
            <div class="meta-line">새 재생목록에 추가하지 않음</div>
          </div>
          <button class="candidate-action" type="button" data-index="${index}" data-video="">${
            skipSelected ? "선택됨" : "선택"
          }</button>
        </div>
      </div>
    </article>
  `;
}

function bindCandidateButtons() {
  document.querySelectorAll("[data-index][data-video]").forEach((button) => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.index);
      state.selected[index] = button.dataset.video;
      renderMatches();
    });
  });
}

function renderMatches() {
  renderMetrics();

  if (state.matches.length === 0) {
    els.matchList.innerHTML = '<div class="empty-state">후보 목록이 비어 있습니다.</div>';
    setBusy(state.busy);
    return;
  }

  els.matchList.innerHTML = state.matches.map(renderMatch).join("");
  bindCandidateButtons();
  setBusy(state.busy);
}

function defaultNewTitleFromSelection() {
  const selected = state.playlists.find((playlist) => playlist.id === els.playlistSelect.value);
  if (selected) {
    els.newTitleInput.value = `${selected.title} - Music Videos`;
  }
}

async function loadConfig() {
  state.config = await api("/api/config");
  renderAuth();
}

async function loadMe() {
  try {
    const payload = await api("/api/me");
    state.me = payload.channel;
  } catch (error) {
    if (error.status !== 401) setNotice("error", error.message);
    state.me = null;
  }
  renderAuth();
}

async function loadPlaylists() {
  if (!state.me) return;
  setBusy(true, "불러오는 중");
  try {
    const payload = await api("/api/playlists");
    state.playlists = payload.playlists || [];
    renderPlaylists();
    setNotice("", state.playlists.length ? "" : "내 재생목록을 찾지 못했습니다.");
  } catch (error) {
    setNotice("error", error.message);
  } finally {
    setBusy(false);
  }
}

async function findMatches() {
  const playlistId = parsePlaylistId(els.playlistInput.value || els.playlistSelect.value);
  if (!playlistId) {
    setNotice("error", "원본 재생목록 URL 또는 ID를 입력해 주세요.");
    return;
  }

  renderResult(null);
  setNotice("", "");
  state.matches = [];
  state.selected = {};
  state.matchMeta = null;
  renderMatches();
  setBusy(true, "검색 중");

  try {
    const payload = await api("/api/match", {
      method: "POST",
      body: {
        playlistId,
        maxItems: Number(els.maxItemsInput.value || 10),
        searchLimit: Number(els.searchLimitInput.value || 5)
      }
    });

    state.matches = payload.matches || [];
    state.matchMeta = payload;
    state.selected = {};
    state.matches.forEach((match, index) => {
      state.selected[index] = match.selectedVideoId || "";
    });
    setNotice(
      "success",
      `${formatNumber(state.matches.length)}개 원본에서 후보를 찾았습니다. 실제 검색 호출: ${formatNumber(
        payload.searchCostEstimate || 0
      )}, 캐시 사용: ${formatNumber(payload.cachedCount || 0)}`
    );
  } catch (error) {
    setNotice("error", error.message);
  } finally {
    setBusy(false);
    renderMatches();
  }
}

async function createPlaylist() {
  const matches = state.matches
    .map((match, index) => ({
      sourceVideoId: match.source.videoId,
      sourceTitle: match.source.title,
      selectedVideoId: state.selected[index]
    }))
    .filter((match) => match.selectedVideoId);

  if (matches.length === 0) {
    setNotice("error", "선택된 후보가 없습니다.");
    return;
  }

  setBusy(true, "생성 중");
  setNotice("", "");

  try {
    const payload = await api("/api/create-playlist", {
      method: "POST",
      body: {
        title: els.newTitleInput.value,
        privacyStatus: els.privacySelect.value,
        dedupe: els.dedupeInput.checked,
        matches
      }
    });
    renderResult(payload);
    setNotice("success", "새 YouTube 재생목록을 만들었습니다.");
  } catch (error) {
    setNotice("error", error.message);
  } finally {
    setBusy(false);
  }
}

function selectBest() {
  state.matches.forEach((match, index) => {
    state.selected[index] = match.candidates[0]?.videoId || "";
  });
  renderMatches();
}

function clearSelection() {
  state.matches.forEach((_, index) => {
    state.selected[index] = "";
  });
  renderMatches();
}

function bindEvents() {
  els.loginBtn.addEventListener("click", () => {
    window.location.href = "/auth/start";
  });

  els.logoutBtn.addEventListener("click", async () => {
    await api("/api/logout", { method: "POST" });
    state.me = null;
    state.playlists = [];
    state.matches = [];
    state.selected = {};
    renderPlaylists();
    renderMatches();
    renderAuth();
  });

  els.refreshPlaylistsBtn.addEventListener("click", loadPlaylists);
  els.matchBtn.addEventListener("click", findMatches);
  els.createBtn.addEventListener("click", createPlaylist);
  els.selectBestBtn.addEventListener("click", selectBest);
  els.clearSelectionBtn.addEventListener("click", clearSelection);

  els.playlistSelect.addEventListener("change", () => {
    els.playlistInput.value = els.playlistSelect.value;
    defaultNewTitleFromSelection();
  });
}

async function init() {
  bindEvents();
  renderPlaylists();
  renderMatches();
  setBusy(true, "확인 중");

  try {
    await loadConfig();
    await loadMe();
    if (state.me) await loadPlaylists();
  } catch (error) {
    setNotice("error", error.message);
  } finally {
    setBusy(false);
    renderAuth();
    renderMatches();
  }
}

init();
